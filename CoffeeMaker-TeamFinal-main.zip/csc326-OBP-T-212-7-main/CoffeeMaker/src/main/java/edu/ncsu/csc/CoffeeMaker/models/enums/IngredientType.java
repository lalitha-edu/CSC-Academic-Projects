package edu.ncsu.csc.CoffeeMaker.models.enums;

/**
 * Enumerator that holds the types of ingredients in IngredientType 
 */
public enum IngredientType {
	/** COFFEE, MILK, PUMPKIN_SPICE, WHIPPED_CREAM, VANILLA, SUGAR, CHOCOLATE */
    COFFEE, MILK, PUMPKIN_SPICE, WHIPPED_CREAM, VANILLA, SUGAR, CHOCOLATE;
}
